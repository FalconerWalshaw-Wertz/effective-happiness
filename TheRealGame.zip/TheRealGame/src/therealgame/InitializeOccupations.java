package therealgame;

import therealgame.Model.Occupation;
import therealgame.Model.OccupationList;

public class InitializeOccupations {

    public InitializeOccupations() {
        OccupationList.getInstance().clear();
        OccupationList.saveOcc();
        Occupation userOcc = new Occupation("Deadbeat Loser", 0);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Police Officer", 54148);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Programmer", 72921);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Teacher", 52363);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Physician", 246291);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Janitor", 36123);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Plumber", 50000);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("Drug Dealer", 24000);
        OccupationList.getInstance().add(userOcc);
        userOcc = new Occupation("College Professor", 114134);
        OccupationList.getInstance().add(userOcc);
        OccupationList.saveOcc();
    }
}
