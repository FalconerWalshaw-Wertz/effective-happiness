package therealgame.Model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class OccupationList extends ArrayList<Occupation> implements Serializable {

    private static OccupationList instance;

    private OccupationList() {
    }

    public static synchronized OccupationList getInstance() {
        if (instance == null) {
            instance = new OccupationList();
            instance.readOcc();
        }
        return instance;
    }

    public static void saveOcc() {
        try {
            FileOutputStream fileOut
                    = new FileOutputStream("occupations.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(instance);
            out.close();
            fileOut.close();
            //System.out.printf("Serialized data is saved in occupations.ser");
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public static void readOcc() {
        try {
            FileInputStream fileIn = new FileInputStream("occupations.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            instance = (OccupationList) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException i) {
        } catch (ClassNotFoundException c) {
            instance = new OccupationList();
            System.out.println("New List Formed");
        }
        if (instance == null) {
            therealgame.InitializeOccupations io = new therealgame.InitializeOccupations();
        }
    }
}
