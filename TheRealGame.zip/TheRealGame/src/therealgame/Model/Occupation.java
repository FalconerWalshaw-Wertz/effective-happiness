package therealgame.Model;

import java.io.Serializable;

public class Occupation implements Serializable {

    private String name;
    private int salary;

    public Occupation(String namei, int salaryi) {
        name = namei;
        salary = salaryi;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the salary
     */
    public int getSalary() {
        return salary;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(int salary) {
        this.salary = salary;
    }

}
