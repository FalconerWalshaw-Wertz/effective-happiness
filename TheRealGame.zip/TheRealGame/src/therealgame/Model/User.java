package therealgame.Model;

public class User {

    private Occupation currentjob;

    public User() {
    }

    public Occupation getJob() {
        return currentjob;
    }

    public void setJob(Occupation newjob) {
        currentjob = newjob;
    }
}
