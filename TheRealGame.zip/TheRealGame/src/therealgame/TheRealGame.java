package therealgame;

import java.io.IOException;

public class TheRealGame {

    public static void main(String[] args) throws IOException {
        therealgame.View.TextTerminalView ttv = new therealgame.View.TextTerminalView();
        // Should only be run if the Occupations.ser file needs to be reset/updated
        // InitializeOccupations io = new InitializeOccupations();
    }

}
