/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package therealgame.View;

import java.io.IOException;
import java.util.Scanner;
import therealgame.Controller.TTVController;
import therealgame.Model.User;

/**
 *
 * @author falconer
 */
public class TextTerminalView {

    private User use = new User();
    private TTVController con = new TTVController(this,use);
    private Scanner sc = new Scanner(System.in);

    public TextTerminalView() throws IOException {

        System.out.println("Enter 'y' for your job.");
        String input = sc.next();
        if (input.equals("y")) {
            use.setJob(con.RandomOccupation());
            System.out.println("Job: " + con.getOccName() + "\nSalary: " + con.getOccSalary());
        } else {
            System.out.println("Job: Failure at life\nSalary: Learn to press buttons");
        }
        System.out.println("Enter 'o' to check your occupation, or 's' to check your salary, or press 'q' to quit");
        input = sc.next();
        con.CheckInput(input);

    }

    /**
     * @return the use
     */
    public User getUse() {
        return use;
    }

    /**
     * @param use the use to set
     */
    public void setUse(User use) {
        this.use = use;
    }

    /**
     * @return the con
     */
    public TTVController getCon() {
        return con;
    }

    /**
     * @param con the con to set
     */
    public void setCon(TTVController con) {
        this.con = con;
    }

    /**
     * @return the sc
     */
    public Scanner getSc() {
        return sc;
    }

    /**
     * @param sc the sc to set
     */
    public void setSc(Scanner sc) {
        this.sc = sc;
    }


}
