/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package therealgame.Controller;

import java.util.Random;
import therealgame.Model.Occupation;
import therealgame.Model.OccupationList;
import therealgame.Model.User;
import therealgame.View.TextTerminalView;

/**
 *
 * @author falconer
 */
public class TTVController {

    User use;
    therealgame.View.TextTerminalView view;

    public TTVController(TextTerminalView viewin, User user) {
        use = user;
        view = viewin;
    }

    //Generates a random occupation and assigns it to the user
    public Occupation RandomOccupation() {
        OccupationList.readOcc();
        Random r = new Random();
        int i = r.nextInt(OccupationList.getInstance().size());
        Occupation userOcc = OccupationList.getInstance().get(i);
        return userOcc;
    }

    public String getOccName() {
        return use.getJob().getName();
    }

    public int getOccSalary() {
        return use.getJob().getSalary();
    }
        public void CheckInput(String input) {
        if (null != input) {
            switch (input) {
                case "o":
                    System.out.println("Job: " + getOccName());
                    input = view.getSc().next();
                    this.CheckInput(input);
                    break;
                case "s":
                    System.out.println("Salary: " + getOccSalary());
                    input = view.getSc().next();
                    this.CheckInput(input);
                    break;
                case "q":
                    System.exit(0);
                default:
                    System.out.println("Not a valid character.");
                    input = view.getSc().next();
                    this.CheckInput(input);
                    break;
            }
        }
    }
}
